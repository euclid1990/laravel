<?php

namespace App\Repositories;

interface PermissionRepositoryInterface extends AppRepositoryInterface
{
    
}
