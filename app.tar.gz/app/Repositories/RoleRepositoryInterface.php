<?php

namespace App\Repositories;

interface RoleRepositoryInterface extends AppRepositoryInterface
{
    //
}
